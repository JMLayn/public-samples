# Prerequisites
- Have OpsWorks Chef Automate server up and running
- Have credentials and starter kit downloaded

# Demo steps
- From the S3 bucket provided in the workshop, download cfn_chef_cookbook_testing.json and the example_cookbook.zip file.

- Create stack (from cfn_chef_cookbook_testing.json)

- Clone CodeCommit repo (currently called git clone aws_ow_cm_test_cookbook. yes, we'll change it)

```
git clone https://git-codecommit.us-east-1.amazonaws.com/v1/repos/aws_ow_cm_test_cookbook
```

- Move or copy the example_cookbook.zip file to the local repo directory.

- Unzip the contents of the example_cookbook.zip file into the repo directory.

```
unzip example_cookbook.zip
```

- Commit changes to the repository and push to master

```
git add .
git commit -am 'first commit'
git push origin master
```

- *watch CodePipeline run and invoke CodeBuild*
- *tests will run and pass or fail depending on what we want to show initially.*
- *if tests pass you will manually have to approve the next stage of the CodePipeline*
- *after the manual approval, the cookbook and its dependencies will be uploaded to the OpsWorks Chef Automate server using Berkshelf*
